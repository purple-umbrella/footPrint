const express = require('express');
const  app = express();
const router = express.Router();
const path = require('path');

app.engine('html', require('express-art-template'));
app.set('view options', {
    debug: process.env.NODE_ENV !== 'production'
});

router.get('/',(req,res) => {
    res.render('index.html')
})
// app.use((req,res,next) => {
//     console.log(req.url);
//     next();
// })
app.use(express.static(path.join(__dirname,'/public')))
app.use(router);
app.listen('12306',() => {
    console.log('port in 12303')
})