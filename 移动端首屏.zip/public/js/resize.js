(function (doc, win, designWidth) {
    const html = doc.documentElement;
    const refreshRem = () => {
        const clientWidth = html.clientWidth;
        if (clientWidth >= designWidth) { //给宽度一个最大值，如果设备的宽度已经超过设计稿的尺寸了，统一按一个值去算（传的第三个参数）
            html.style.fontSize = '100px';
        } else {
            // col * (clientWidth / designWidth) <==> clientWidth / (designWidth / col)
            html.style.fontSize = 100 * (clientWidth / designWidth) + 'px';
        }
    };
    const getRem = (px) => {
        return px / 100;
    }
    doc.addEventListener('DOMContentLoaded', refreshRem);
    window.addEventListener('resize',refreshRem,{passive:true});
    window.getRem = getRem;
})(document, window, 750);