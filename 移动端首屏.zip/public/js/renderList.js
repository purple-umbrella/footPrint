(function () {
    let data = [
        {
            name: "王者荣耀",
            img:"imgs/game2.jpg",
            detail: "《王者荣耀》是腾讯天美工作室推出的英雄竞技手游,不是一个人的王者,而是团队的荣耀!5v5王者峡谷PVP对战"
        },
        {
            name: "我的世界",
            img:"imgs/game1.jpg",
            detail: "网易游戏代理的《我的世界》(Minecraft)手游,你想玩的,这里都有!作为中国顶尖UGC游戏平台,《我的世界》汇聚全球优秀创造者提供海量玩法内容。"
        },
        {
            name: "天天酷跑",
            img:"imgs/game6.jpg",
            detail: "腾讯游戏《天天酷跑》轻松好玩、简单时尚。《天天酷跑》时尚Q版角色与酷炫道具的完美结合!滑行玩法让跑酷与众不同!"
        },
        {
            name: "时空猎人",
            img:"imgs/game5.jpg",
            detail: "时空猎人官方网站。经典街机横版格斗风,是2.5亿玩家的格斗游戏首选!极佳的打击感加上极爽的战斗快感,让你体验一场指尖的格斗风暴。"
        },
        {
            name: "天天酷跑",
            img:"imgs/game6.jpg",
            detail: "腾讯游戏《天天酷跑》轻松好玩、简单时尚。《天天酷跑》时尚Q版角色与酷炫道具的完美结合!滑行玩法让跑酷与众不同!"
        },



    ];
    let infoWrap = document.getElementsByClassName('infoList')[0];
    let str = "";

    data.forEach(ele => {
        str += `<article>
                    <a href="#">
                    <div class="img">
                    <img src=${ele.img} alt="">
                    </div>
                     <div class="text">
                    <h4>${ele.name}</h4>
                    <p>${ele.detail}</p>
                    </div>
                     </a>
                 </article>`;
    });
    infoWrap.innerHTML = str;


})()