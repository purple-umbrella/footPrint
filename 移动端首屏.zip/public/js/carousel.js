(function (doc, win) {
    let carousel = doc.getElementsByClassName('carousel')[0];
    let imgList = doc.getElementsByClassName('list')[0];
    let dots = doc.getElementsByClassName('dots')[0];
    let dotsSpan = dots.getElementsByTagName('span');
    let imgListLen = 0;
    let timer = null;
    let clientWidth = doc.documentElement.clientWidth;
    let limit = clientWidth / 8;
    let preIndex = 0;
    let curIndex = 0;
    let start = {};
    let curPosition = {};
    let distance = {};

    init();
    function init() {
        let str = "";
        // 复制一份图片并插入
        imgList.innerHTML += imgList.innerHTML;
        imgListLen = imgList.children.length
        // curIndex = imgListLen / 2;
        css(imgList, { 'width': imgListLen * clientWidth});
        for (let i = 0; i < imgListLen / 2; i++) {
            str += `<span ${i == 0 ? "class=active" : ""}></span>`;
        }
        dots.innerHTML = str;
        bindEvent();
        autoMove(true)
    }

    function bindEvent() {
        carousel.addEventListener('touchstart', e => {
            e.preventDefault();
            autoMove(false);
            let ev = e.changedTouches[0];
            start.x = ev.pageX;
            start.y = ev.pageY;
            curPosition.x = curIndex * -clientWidth;
        }, { passive: false });

        carousel.addEventListener('touchmove', e => {
            let ev = e.changedTouches[0];
            let { x, y } = start;
            let { x: curX, y: curY } = curPosition;
            let disX = ev.pageX - x;
            // let disY = ev.pageY - y;
            distance.x = disX;
            // distance.y = disY;
            css(imgList, { 'translateX': curX + disX, 'transition': 'all 0.1s ease-in' });

        });

        carousel.addEventListener('touchend', () => {
            if (Math.abs(distance.x) > limit) {
                if (distance.x < 0) {
                  curIndex ++;
                } else {
                    curIndex--;
                }
            }
            css(imgList, { 'translateX': -clientWidth * curIndex });
            handleDots(curIndex);
            autoMove(true);

        });
        imgList.addEventListener('transitionend',() => {
            if (curIndex == 0 || curIndex == (imgListLen - 1)) {
                curIndex = curIndex == 0 ? imgListLen / 2 : imgListLen / 2 - 1;
                css(imgList, { 'translateX': curIndex * -clientWidth, 'transition': '' });

            }
        })
    }

    function handleDots(currentIndex) {
        dotsSpan[preIndex].className = "";
        let newTarget = currentIndex % (imgListLen / 2);
        dotsSpan[newTarget].className = "active";
        preIndex = newTarget;
    }

    function autoMove(flag) {
        timer && clearInterval(timer)
        if(flag) {
            timer = setInterval(() => {
                curIndex ++;
                css(imgList, { 'translateX': -clientWidth * curIndex,'transition': 'all 0.2s ease-in' });
                curPosition.x = curIndex * -clientWidth;
                handleDots(curIndex);
            }, 3000);
        }
    }
    
})(document, window, css)