function getData(url, param) {
  let result = null;
  let xhr = null;
  if (window.XMLHttpRequest) {
    xhr = new XMLHttpRequest();
  } else {
    xhr = new ActiveXObject('Microsoft.XMLHTTP');
  }
  if (typeof param === 'string') {
    xhr.open('GET', `${url}?${param}`, false);
  } else if (typeof param === 'object') {
    let str = '';
    for (const prop in param) {
      str += `${prop}=${param[prop]}&`;
    }
    xhr.open('GET', `${url}?${str}`, false);
  } else {
    xhr.open('GET', `${url}?${param.toString()}`, false);
  }
  xhr.onreadystatechange = function () {
    if (xhr.readyState == 4) {
      if (xhr.status == 200) {
        result = JSON.parse(xhr.responseText);
      }
    }
  };
  xhr.send();
  return result;
}

export default getData;
