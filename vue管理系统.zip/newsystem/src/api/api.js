import xhr from './index.js';
// console.log(xhr)
const api = {
  getPageData() {
    return new Promise((res, rej) => {
      const data = xhr('http://open.duyiedu.com/api/student/findByPage', {
        appkey: 'purpleumbrella_1571310192509',
        page: 1,
        size: 3,
      });
      if (data.status === 'success') {
        res(data.data.findByPage);
      } else {
        rej(new Error('getPageData'));
      }
    });
  },
  deleteData(id) {
    return new Promise((res, rej) => {
      const data = xhr('http://open.duyiedu.com/api/student/delBySno', {
        appkey: 'purpleumbrella_1571310192509',
        sNo: id,
      });
      if (data.status === 'success') {
        res(data.msg);
      } else {
        rej(new Error('deleteData'));
      }
    });
  },
  addStudent(payload) {
    const obj = Object.assign({ appkey: 'purpleumbrella_1571310192509' }, payload);
    return new Promise((res, rej) => {
      const data = xhr('http://open.duyiedu.com/api/student/addStudent', obj);
      if (data.status && data.status === 'success') {
        res(data.msg);
      } else {
        rej(data.msg);
      }
    });
  },
  /** payload是修改信息的形参 */
  changeData(payload) {
    const obj = Object.assign({ appkey: 'purpleumbrella_1571310192509' }, payload);
    return new Promise((res, rej) => {
      const data = xhr('http://open.duyiedu.com/api/student/updateStudent', obj);
      if (data.status === 'success') {
        res(data.msg);
      } else {
        rej(data.msg);
      }
    });
  },

};


export default api;


// return new Promise((res,rej) => {
//     let data = xhr.getAll(,)
//   setTimeout(()=>{console.log(data)},2000)
//   if(data.status == 'success') {
//       res(data.data);
//   }else{
//       rej('error')
//   }
//     })
