<template>
  <div id="app">
    <div class="header">
       <div class="logo">
                <router-link :to="{path:'/home'}" tag="div" class="imgArea"></router-link>
                <span>管理系统</span>
            </div>
    </div>
    <div class="content">
      <div class="leftMenu">
           <dl class="menuList">
                <dt class="title">学生管理</dt>
               <router-link tag="dd" :to="{path:'/home/showStudent'}">学生列表</router-link>
               <router-link tag="dd" to="/home/addStudent">新增学生</router-link>
            </dl>
      </div>
      <div class="rightShow">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
#app {
  height: 100%;
  .header{
        height: 70px;
        background-color: #354457;
    .logo {
       padding-left: 20px;
        line-height: 70px;
        .imgArea {
            display: inline-block;
            width: 28px;
            height: 28px;
            vertical-align: middle;
            border-radius: 5px;
            margin-right: 8px;
            background: url("./assets/image/logo.png");
            background-size: cover;
            background-repeat: no-repeat;
            cursor: pointer;
        }
        span {
            font-size: 14px;
            color: #b3bcc5;
        }
    }
}
.content{
  height: calc(100% - 70px);
  .leftMenu{
        height: 100%;
        float: left;
        width: 200px;
        color: rgb(236, 236, 236);
        background-color: #4d5e70;
    .menuList{
        dt {
            padding-left: 8px;
            font-weight: bold;
            height: 40px;
            line-height: 40px;
        }
        dd {
            height: 40px;
            line-height: 40px;
            padding-left: 30px;
            cursor: pointer;
            &.linkaAtive{
                background-color: #ddd;
                color: #354457;
            }
        }
        & dd:hover {
            background-color: rgba(255, 255, 255, 0.5);
            color: #354457;
        }
    }
  }
  .rightShow{
        float: right;
        width: calc(100% - 200px);
        height: 100%;
  }
    &:after{
        clear: both;
        content: "";
        display: block;
    }
}
}

</style>
