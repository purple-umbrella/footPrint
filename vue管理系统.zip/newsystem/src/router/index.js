import Vue from 'vue';
import VueRouter from 'vue-router';
import Home from '@/components/viewPage.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    redirect: '/home',
  },
  {
    path: '/home',
    name: 'home',
    component: Home,
    redirect: '/home/addStudent',
    children: [
      {
        path: 'showStudent',
        name: 'showStudent',
        component: () => import('@/views/showStudent'),
      },
      {
        path: 'showStudent/:index',
        name: 'editPage',
        component: () => import('@/views/addStudent'),
      },
      {
        path: 'addStudent',
        nameL: 'addStudent',
        component: () => import('@/views/addStudent'),
      },
    ],
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
