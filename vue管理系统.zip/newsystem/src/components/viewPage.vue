<template>
  <div class="view">
    <router-view></router-view>
    </div>
</template>

<script>
export default {
  mounted() {
    /** 获取后台全部数据 */
  },
  data() {
    return {

    };
  },
};
</script>

<style lang="scss" scoped>
    .view{
        height: 100%;
    }
</style>
