<template>
  <div class="item">
    <div class="temp" v-for="(prop,i) in list " :key="prop.sNo">
      <span>{{prop.sNo}}</span>
      <span>{{prop.name}}</span>
      <span>{{prop.sex == 0 ? '男' :'女'}}</span>
      <span>{{prop.email}}</span>
      <span>{{prop.birth}}</span>
      <span>{{prop.phone}}</span>
      <span>{{prop.address}}</span>
      <div class="btnBox">
        <router-link tag="span" class="editBtn" :to="{name: 'editPage',params: {index: i}}" @click="handleEdit(prop.sNo)">编辑</router-link>
        <span class="deleteBtn" @click="handleDelete(prop.sNo)">删除</span>
      </div>
<!-- {{list && list.findByPage}} -->
    </div>

  </div>
</template>

<script>
export default {

  computed: {
    list() {
      return this.$store.state.stuSystem.allData;
    },
  },

  methods: {

    /** 处理编辑按钮事件 */
    handleEdit(id) {
        
    },
    /** 处理删除按钮事件 */
    handleDelete(id) {
      this.$store.dispatch('stuSystem/deleteItem',id);
    },
  },
};
</script>

<style lang="scss" scoped>
$itemLineHeight: 25px;
.item {
  .temp {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr 2fr 1fr 2fr 2fr 2fr;
    height: $itemLineHeight;
    .btnBox {
      span {
        display: inline-block;
        font-size: 14px;
        // padding: 1px 2px;
        color: #999;
        font-weight: bold;
        box-shadow: 1px 2px 3px rgb(199, 199, 199);
        border: 1px solid #777;
        &:hover{
          background-color: #fff;
          color: #000;
        }
        cursor: pointer;
        &.editBtn {
          margin-right: 2.5px;
        }
        &.deleteBtn {
          margin-left: 2.5px;
        }
      }
    }
    span,
    .btnBox {
      line-height: $itemLineHeight;
      text-align: center;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
}
</style>
