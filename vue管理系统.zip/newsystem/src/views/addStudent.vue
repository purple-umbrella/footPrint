<template>
     <div class="addStudent">
    <div class="addStudentForm">
      <div>
        <label for="name">姓名</label>
        <input type="text" id="name" placeholder="请输入名字" v-model="formData.name" />
      </div>
      <div>
        <label for>性别</label>
        <input type="radio" id="male" value="0" v-model="formData.sex" />
        <label for="male" class="label-sex">男</label>
        <input type="radio" id="female" value="1" v-model="formData.sex" />
        <label for="female" class="label-sex">女</label>
      </div>
      <div>
        <label for="sNo">学号</label>
        <input type="text" id="sNo" placeholder="请输入学号" v-model="formData.sNo" />
      </div>
      <div>
        <label for="email">邮箱</label>
        <input type="text" id="email" placeholder="请输入邮箱" v-model="formData.email" />
      </div>
      <div>
        <label for="birth">年龄</label>
        <input type="text" id="birth" placeholder="请输入出生年" v-model="formData.birth" />
      </div>
      <div>
        <label for="phone">手机号</label>
        <input type="text" id="phone" placeholder="请输入手机号" v-model="formData.phone" />
      </div>
      <div>
        <label for="address">住址</label>
        <input type="text" id="address" placeholder="请输入地址" v-model="formData.address" />
      </div>
      <div class="btnWrap">
        <input type="submit" class="btn"  @click="handleClick" />
        <input type="reset" class="btn" />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props:{

  },
  beforeRouteEnter(to,from,next) {
    if(to.name == 'editPage' && typeof(to.params.index) == 'number') {
       let i = to.params.index;
        next(vm => {
          vm.changeFlag = true;
         vm.setFormData(i);
    });
    }else{
      next();
    }
   
  },
  data() {
    return {
      changeFlag:false,
       formData: {
        sNo: '',
        name: '',
        sex: 0,
        birth: '',
        phone: '',
        address: '',
        email: '',
      },
    }
  },
  computed: {
     sign() {
      return this.$store.state.stuSystem.successFlag;
    }
  },
  watch: {
    sign() {
        this.$router.push('/home/showStudent');
         this.$store.state.stuSystem.successFlag = false;
    }
  },
 
  methods: {
    setFormData(i) {
      let curPageData = this.$store.state.stuSystem.allData;
      this.formData = curPageData[i];
    },
    handleClick() {
      if(this.changeFlag) {
        //调用修改信息接口
        
        this.$store.dispatch('stuSystem/changeItem',this.formData);
        this.changeFlag = false;
      }else{
        //调用增加信息接口
    this.$store.dispatch('stuSystem/addItem',this.formData);

      }
  }
  },
  
};
</script>

<style lang="scss" scoped>
.addStudent{
    height: 100%;
    position: relative;
    background-color: #eee;
    .addStudentForm{
        width: 400px;
        position: absolute;
        top: 45%;
        left:50%;
        transform: translateX(-50%) translateY(-50%);

        & input[type=text]{
            width: 200px;
            height: 22px;
            padding: 2px 0 2px 5px;
        }
        label{
            width: 100px;
            display: inline-block;
            text-align: right;
            padding-right: 10px;
            color: #000;
            font-size: 16px;
        }
        input:{
            outline: none;
        }
        label.label-sex {
            width: 20px;
            text-align: left;

        }
        div {
            margin: 10px 0;
        }
        .btnWrap{
            text-align: center;
            .btn {
                padding: 5px 25px;
                margin-left: 8px;
            }
        }

    }
}
</style>
