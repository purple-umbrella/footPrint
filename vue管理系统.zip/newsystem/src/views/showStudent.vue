<template>
    <div class="studentList">
        <div class="title">
            <span>学号</span>
            <span>姓名</span>
            <span>性别</span>
            <span>邮箱</span>
            <span>年龄</span>
            <span>手机号</span>
            <span>住址</span>
            <span>操作</span>
        </div>
        <studentItem />
    </div>
</template>

<script>
import studentItem from '@/views/studentItem';

export default {
  mounted() {
    this.$store.dispatch('stuSystem/getPage');
  },
  data() {
    return {
    };
  },
  components: {
    studentItem,
  },
};
</script>

<style lang="scss" scoped>
$titleLineHeight:30px;
$itemLineHeight:25px;
.studentList{
        .title{
            width: 100%;
            display: grid;
            grid-template-columns:1fr 1fr 1fr 2fr 1fr 2fr 2fr 2fr;
            height: $titleLineHeight;
            background-color: #eee;
            span{
                text-align: center;
                line-height: $titleLineHeight;
            }
        }
    }
</style>
