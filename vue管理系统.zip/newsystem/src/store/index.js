import Vue from 'vue';
import Vuex from 'vuex';
import Api from '@/api/api.js';

Vue.use(Vuex);

export default new Vuex.Store({
  state: {

  },
  mutations: {
  },
  actions: {
  },
  modules: {
    stuSystem: {
      namespaced: true,
      state: {
        allData: null,
        addStuInfo: null,
        successFlag: false,
      },
      mutations: {
        setPageData(state, { val }) {
          state.allData = val;
        },
        addStudentInfo({ state }, payload) {
          state.addStuInfo = payload;
        },
      },
      actions: {
        getPage({ state, commit }) {
          Api.getPageData()
            .then((res) => {
              // console.log(state.successFlag);
              commit('setPageData', { val: res });
            }).catch((msg) => { console.log(msg); });
        },
        deleteItem({ dispatch }, index) {
          Api.deleteData(index).then((res) => {
            dispatch('getPage');
            alert(res);
          }).catch((msg) => {
            console.log(msg);
          });
        },
        addItem({ state, dispatch }, config) {
          Api.addStudent(config).then((res) => {
            state.successFlag = true;
            dispatch('getPage');
            alert(res);
          }).catch((msg) => {
            alert(msg);
          });
        },
        changeItem({ state, dispatch }, config) {
          Api.changeData(config).then((res) => {
            state.successFlag = true;
            dispatch('getPage');
            alert(res);
          }).catch((msg) => {
            alert(msg);
          });
        },
      },
    },
  },
});
